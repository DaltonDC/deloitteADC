///  <reference types="Cypress"/>

describe('firstsuite to TCs', () => {
  beforeEach(() => {
    cy.visit(('https://www.liverpool.com.mx/tienda/pantallas/catst14457077'),{
      headers:{
        "Accepted": "application/json, text/plain, */*",
        "User-Agent": "axios/0.18.0"
      }
    }) 
  })

  it('buscando un elemnto especifico',() =>{
   var cuen = 0;
   //Seleccionar valor mayor a 10000
   cy.get('input[type="radio"]').last().check({force: true})

   //seleccionando equipo
   cy.get('[data-prodid="1119625081"] > a > .m-plp-card-container').dblclick({force: true})

   //contando elementos
   cy.get('.sliderTray___-vHFQ')
   .find('.img-viewer')
   .each(($el1,index,$list) =>{
    cuen = cuen + 1
     if(cuen === 6){
       cy.log("el valor total de imagenes es: ", cuen)
     }
   }) 
   
   //verificando precio actual
   if (cy.get('.a-product__paragraphDiscountPrice').contains('16,799')){
    cy.log("El precion 16,799 es el actual")
   }

   //validando la tabla general
   //abrir tabla general 
   cy.get('.mb-grouped > :nth-child(1)').click({force: true})
   //validando marca
   cy.get('.show-accord > .row > :nth-child(1) > .table > :nth-child(2) > tr > :nth-child(2)').should('have.text','HISENSE')
   //validando año modelo
   cy.get('.show-accord > .row > :nth-child(1) > .table > :nth-child(3) > tr > :nth-child(2) > .productSpecsGrouped_regular').should('have.text','2022')
   //validando mmodelo comercial
   cy.get('.show-accord > .row > :nth-child(2) > .table > tbody > tr > :nth-child(2) > .productSpecsGrouped_regular').should('have.text','75A6H')

 })
})





